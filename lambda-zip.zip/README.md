lambdaUnzipper

2015/6/12 AWS Lambda sample function.  
unzip file and put contents to target S3 bucket.

http://qiita.com/saku/items/52c6a8ddd1dc510e6bc7

MIT License
